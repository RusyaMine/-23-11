class Artist:
    def __init__(self, name, country, age):
        self.name = name
        self.country = country
        self.age = age


class Album:
    def __init__(self, title, artist):
        self.title = title
        self.artist = artist


class Studio:
    def __init__(self, name):
        self.name = name
        self.albums = []

    def add_album(self, album):
        self.albums.append(album)

    def show_albums(self):
        print(f"Albums in {self.name}:")
        for a in self.albums:
            print(f"- {a.title} by {a.artist.name} (Country - {a.artist.country}, years old - {a.artist.age})")


artist = Artist(input("Artist: "), input("Contry: "), int(input("Years old: ")))

album = Album("After Hours", artist)

studio = Studio("XO Records")
studio.add_album(album)
studio.show_albums()
