class GameCharacter:
    game_name = "Valheim"

    def __init__(self,name,health,gold,power):
        self.name = name
        self.health = health
        self.__gold = gold
        self.power = power
    def attack(self, target):
        print(self.name,"attacks",target.name,"for",self.power,"damage!")
        target.health -= self.power


    def get_balan(self):
        return self.__gold
    def alive(self):
        return self.health>0
    def stat(self):
        print("-------------------")
        print("Game:",self.game_name)
        print(self.name,"Stat's")
        print("Health:",self.health)
        print("Gold:", self.__gold)
        print("Power",self.power)
        print("-------------------")

player = GameCharacter("Scrabic",100,1005,35)
monster = GameCharacter("Troll",250,1075,75)

player.stat()
monster.stat()
player.attack(monster)
monster.stat()